"""
TTCS 桌面 UI — 角色库 + 工作区  (V0.4 滑动条 + 固化库)
"""

import os
import shutil
import time
import av

from PySide6.QtWidgets import (
    QApplication, QWidget, QHBoxLayout, QVBoxLayout,
    QLabel, QListWidget, QListWidgetItem, QPushButton,
    QTextEdit, QProgressBar, QFileDialog, QInputDialog,
    QMessageBox, QSplitter, QFrame, QGroupBox,
    QSlider, QMenu,
)
from PySide6.QtCore import Qt

from utils import get_asset_path, get_profiles_dir, load_profiles, save_profile, delete_profile
from tts_worker import TTSWorker
import asr_worker

# ---------------------------------------------------------------------------
# 6 个内置角色（不可删除）
# ---------------------------------------------------------------------------

BUILTIN_ROLES = [
    {"name": "女声1 (晓柔)",      "key": "__builtin_xiaorou__",  "type": "matcha",
     "model_dir": "bin/models/matcha",  "model_file": "model-steps-3.onnx"},
    {"name": "女声2 (Melo)",      "key": "__builtin_melo__",     "type": "vits",
     "model_dir": "bin/models/vits_female_2", "model_file": "model.onnx"},
    {"name": "女声3 (Fanchen)",   "key": "__builtin_fanchen_f__","type": "vits",
     "model_dir": "bin/models/vits_female_3", "model_file": "vits-zh-hf-fanchen-C.onnx", "sid": 0},
    {"name": "男声1 (WNJ)",       "key": "__builtin_wnj__",      "type": "vits",
     "model_dir": "bin/models/vits_male_1",   "model_file": "vits-zh-hf-fanchen-wnj.onnx"},
    {"name": "男声2 (霸总)",      "key": "__builtin_bazong__",   "type": "vits",
     "model_dir": "bin/models/vits_multi_zh", "model_file": "model.onnx", "sid": 4},
    {"name": "男声3 (Fanchen男)", "key": "__builtin_fanchen_m__","type": "vits",
     "model_dir": "bin/models/vits_female_3", "model_file": "vits-zh-hf-fanchen-C.onnx", "sid": 50},
]

BUILTIN_KEYS = {r["key"] for r in BUILTIN_ROLES}


class TtsUI(QWidget):
    """主界面窗口。"""

    def __init__(self):
        super().__init__()
        self.setWindowTitle("TTCS — Text To Cloned Speech  V0.4")
        self.resize(1100, 680)
        self.setMinimumSize(900, 560)

        self._profiles: dict[str, dict] = {}   # name → {wav, text}
        self._role_names: list[str] = []        # 有序显示名列表

        self._init_ui()
        self._load_profiles()

    # ----------------------------------------------------------------
    # UI 构建
    # ----------------------------------------------------------------

    def _init_ui(self):
        root = QHBoxLayout(self)
        root.setContentsMargins(12, 12, 12, 12)

        splitter = QSplitter(Qt.Horizontal)
        splitter.addWidget(self._build_left_panel())
        splitter.addWidget(self._build_right_panel())
        splitter.setStretchFactor(0, 1)
        splitter.setStretchFactor(1, 3)
        splitter.setSizes([280, 780])

        root.addWidget(splitter)

    def _build_left_panel(self) -> QWidget:
        panel = QFrame()
        panel.setObjectName("leftPanel")
        layout = QVBoxLayout(panel)
        layout.setContentsMargins(8, 8, 8, 8)

        title = QLabel("角色库")
        title.setObjectName("panelTitle")
        layout.addWidget(title)

        self.role_list = QListWidget()
        self.role_list.setObjectName("roleList")
        self.role_list.setContextMenuPolicy(Qt.CustomContextMenu)
        self.role_list.customContextMenuRequested.connect(self._on_role_context_menu)
        layout.addWidget(self.role_list)

        self.add_btn = QPushButton("➕ 添加定制克隆声音")
        self.add_btn.setObjectName("addBtn")
        self.add_btn.clicked.connect(self._on_add_profile)
        layout.addWidget(self.add_btn)

        return panel

    def _build_right_panel(self) -> QWidget:
        panel = QFrame()
        panel.setObjectName("rightPanel")
        layout = QVBoxLayout(panel)
        layout.setContentsMargins(12, 8, 12, 8)

        title = QLabel("工作区")
        title.setObjectName("panelTitle")
        layout.addWidget(title)

        self.text_edit = QTextEdit()
        self.text_edit.setObjectName("textEdit")
        self.text_edit.setPlaceholderText("在此粘贴口播文稿（支持长文本，自动切片合成）……")
        self.text_edit.setMinimumHeight(200)
        layout.addWidget(self.text_edit, stretch=3)

        # 进度条
        self.progress_bar = QProgressBar()
        self.progress_bar.setObjectName("progressBar")
        self.progress_bar.setValue(0)
        self.progress_bar.setTextVisible(True)
        self.progress_bar.setFormat("%p%")
        layout.addWidget(self.progress_bar)

        # 克隆质量滑动条
        quality_group = QGroupBox("克隆质量")
        quality_layout = QVBoxLayout(quality_group)
        quality_layout.setContentsMargins(8, 4, 8, 4)

        self.quality_label = QLabel("日常快速 (步数:4, 默认平衡)")
        self.quality_label.setObjectName("qualityLabel")
        quality_layout.addWidget(self.quality_label)

        self.quality_slider = QSlider(Qt.Horizontal)
        self.quality_slider.setObjectName("qualitySlider")
        self.quality_slider.setRange(1, 5)
        self.quality_slider.setValue(2)
        self.quality_slider.setTickPosition(QSlider.TicksBelow)
        self.quality_slider.setTickInterval(1)
        self.quality_slider.valueChanged.connect(self._on_quality_changed)
        quality_layout.addWidget(self.quality_slider)

        layout.addWidget(quality_group)

        # 合成按钮
        self.synth_btn = QPushButton("▶️ 开始合成")
        self.synth_btn.setObjectName("synthBtn")
        self.synth_btn.setMinimumHeight(44)
        self.synth_btn.clicked.connect(self._on_synthesize)
        layout.addWidget(self.synth_btn)

        return panel

    # ----------------------------------------------------------------
    # 角色库逻辑
    # ----------------------------------------------------------------

    def _load_profiles(self):
        """加载 profiles.json 并刷新列表。"""
        self.role_list.clear()
        self._profiles = load_profiles()
        self._role_names = list(self._profiles.keys())

        # 6 个内置角色永远排在最前面
        for r in BUILTIN_ROLES:
            item = QListWidgetItem(r["name"])
            item.setData(Qt.UserRole, r["key"])
            self.role_list.addItem(item)

        for name in self._role_names:
            item = QListWidgetItem(name)
            item.setData(Qt.UserRole, name)
            self.role_list.addItem(item)

        # 默认选中第一项
        self.role_list.setCurrentRow(0)

    def _on_role_context_menu(self, pos):
        """右键菜单：删除角色（内置角色禁止删除）。"""
        item = self.role_list.itemAt(pos)
        if item is None:
            return

        role_key = item.data(Qt.UserRole)

        # 内置角色禁止删除
        if role_key in BUILTIN_KEYS:
            QMessageBox.information(self, "提示", "内置角色不可删除。")
            return

        menu = QMenu()
        delete_action = menu.addAction("删除该角色")
        action = menu.exec(self.role_list.viewport().mapToGlobal(pos))
        if action == delete_action:
            self._delete_profile(role_key)

    def _delete_profile(self, role_key: str):
        """删除用户自定义角色。"""
        if role_key in BUILTIN_KEYS:
            return

        reply = QMessageBox.question(
            self, "确认删除",
            f"确定要删除角色「{role_key}」吗？\n此操作不可撤销。",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No,
        )
        if reply != QMessageBox.Yes:
            return

        delete_profile(role_key)
        self._load_profiles()

    def _on_add_profile(self):
        """添加定制克隆声音。"""
        # 1. 选择 WAV 文件
        audio_path, _ = QFileDialog.getOpenFileName(
            self, "选择参考音频", "",
            "Audio Files (*.wav *.m4a *.mp3 *.flac *.aac)"
        )
        if not audio_path:
            return

        # 2. 输入角色名称
        name, ok = QInputDialog.getText(
            self, "角色命名", "请为该克隆角色命名（如：雷军）："
        )
        name = name.strip()
        if not ok or not name:
            return

        # 3. 写入标准 WAV 到 profiles/ 目录（防冲突，非 wav 自动转码）
        profiles_dir = get_profiles_dir()
        os.makedirs(profiles_dir, exist_ok=True)

        safe_name = self._safe_filename(name)
        base = os.path.join(profiles_dir, safe_name)
        dest_wav = f"{base}.wav"
        counter = 1
        while os.path.exists(dest_wav):
            dest_wav = f"{base}_{counter}.wav"
            counter += 1

        ext = os.path.splitext(audio_path)[1].lower()
        if ext == ".wav":
            shutil.copy2(audio_path, dest_wav)
        else:
            self._convert_to_wav(audio_path, dest_wav)

        # 4. 调用 ASR 自动听写（针对转换好的标准 WAV）
        QApplication.setOverrideCursor(Qt.WaitCursor)
        recognized_text = ""
        try:
            recognized_text = asr_worker.recognize_audio(dest_wav)
        except Exception as e:
            import traceback
            QMessageBox.critical(self, "ASR Error", f"STT Failed:\n{traceback.format_exc()}")
            recognized_text = ""
        finally:
            QApplication.restoreOverrideCursor()

        # 5. 输入参考文本
        ref_text, ok = QInputDialog.getMultiLineText(
            self, "参考文本", "请输入该音频对应的参考文本（与音频内容完全一致）：", recognized_text
        )
        if not ok or not ref_text.strip():
            # 如果取消，删除刚复制的 WAV
            if os.path.exists(dest_wav):
                os.remove(dest_wav)
            return

        # 6. 持久化
        wav_filename = os.path.basename(dest_wav)
        save_profile(name, wav_filename, ref_text.strip())

        # 6. 刷新列表
        self._load_profiles()

        QMessageBox.information(
            self, "添加成功",
            f"角色「{name}」已添加到角色库。\n参考音频：{dest_wav}"
        )

    @staticmethod
    def _safe_filename(name: str) -> str:
        """移除非法文件名字符。"""
        return "".join(c for c in name if c not in r'\/:*?"<>|')

    @staticmethod
    def _convert_to_wav(src_path: str, dest_path: str):
        """将任意音频转码为 16kHz 单声道 16-bit WAV。"""
        input_container = av.open(src_path)
        stream = input_container.streams.audio[0]

        resampler = av.AudioResampler(format="s16", layout="mono", rate=16000)

        output_container = av.open(dest_path, "w", format="wav")
        output_stream = output_container.add_stream("pcm_s16le", rate=16000, layout="mono")

        for frame in input_container.decode(stream):
            for resampled in resampler.resample(frame):
                for packet in output_stream.encode(resampled):
                    output_container.mux(packet)

        for resampled in resampler.resample(None):
            for packet in output_stream.encode(resampled):
                output_container.mux(packet)

        for packet in output_stream.encode(None):
            output_container.mux(packet)

        output_container.close()
        input_container.close()

    # ----------------------------------------------------------------
    # 质量滑动条
    # ----------------------------------------------------------------

    _QUALITY_LABELS = {
        1: "极速草稿 (步数:2, 速度极快)",
        2: "日常快速 (步数:4, 默认平衡)",
        3: "优质流畅 (步数:8, 适合长文)",
        4: "精细克隆 (步数:15, 语调更真)",
        5: "母带级 (步数:25, 细节拉满)",
    }

    def _on_quality_changed(self, value: int):
        self.quality_label.setText(self._QUALITY_LABELS.get(value, ""))

    # ----------------------------------------------------------------
    # 合成逻辑
    # ----------------------------------------------------------------

    def _on_synthesize(self):
        """开始合成。"""
        text = self.text_edit.toPlainText().strip()
        if not text:
            QMessageBox.warning(self, "提示", "请先输入口播文稿。")
            return

        current_item = self.role_list.currentItem()
        if current_item is None:
            QMessageBox.warning(self, "提示", "请先在左侧选择一个角色。")
            return

        role_key = current_item.data(Qt.UserRole)

        # 内置角色 → 查找 BUILTIN_ROLES
        if role_key in BUILTIN_KEYS:
            entry = next(r for r in BUILTIN_ROLES if r["key"] == role_key)
            if entry["type"] == "matcha":
                profile = {"type": "matcha"}
            else:
                profile = {
                    "type": "vits",
                    "model_dir": entry["model_dir"],
                    "model_file": entry.get("model_file", "model.onnx"),
                }
                if "sid" in entry:
                    profile["sid"] = entry["sid"]
        else:
            data = self._profiles.get(role_key, {})
            wav_filename = data.get("wav", "")
            wav_path = get_asset_path(f"profiles/{wav_filename}")
            profile = {
                "type": "zipvoice",
                "wav": wav_path,
                "text": data.get("text", ""),
            }

        # 输出路径
        ts = time.strftime("%Y%m%d_%H%M%S")
        output_dir = get_asset_path("output")
        os.makedirs(output_dir, exist_ok=True)
        output_path = os.path.join(output_dir, f"ttcs_{ts}.wav")

        quality = self.quality_slider.value()

        # 禁用按钮
        self.synth_btn.setEnabled(False)
        self.synth_btn.setText("⏳ 合成中……")
        self.progress_bar.setValue(0)

        # 启动 Worker
        self._worker = TTSWorker(text, output_path, profile, quality=quality)
        self._worker.progress.connect(self._on_progress)
        self._worker.finished.connect(self._on_finished)
        self._worker.error.connect(self._on_error)
        self._worker.start()

    def _on_progress(self, pct: int):
        self.progress_bar.setValue(pct)

    def _on_finished(self, output_path: str):
        self.synth_btn.setEnabled(True)
        self.synth_btn.setText("▶️ 开始合成")
        self.progress_bar.setValue(100)

        QMessageBox.information(
            self, "合成完成",
            f"音频已生成：\n{output_path}"
        )

    def _on_error(self, msg: str):
        self.synth_btn.setEnabled(True)
        self.synth_btn.setText("▶️ 开始合成")
        self.progress_bar.setValue(0)

        QMessageBox.critical(
            self, "合成失败",
            f"发生错误：\n{msg}"
        )
