"""
TTCS 后台核心模块：双引擎路由 + 长文切片 + 内存级合成
基于 sherpa_onnx 原生 Python API + numpy，不使用 subprocess
"""

import os
import re
import wave

import numpy as np
import sherpa_onnx
from PySide6.QtCore import QThread, Signal

from utils import get_asset_path

# ---------------------------------------------------------------------------
# TTSWorker
# ---------------------------------------------------------------------------

class TTSWorker(QThread):
    """文本转语音后台工作线程。"""

    progress = Signal(int)       # 当前进度百分比 (0-100)
    finished = Signal(str)       # 输出文件路径
    error    = Signal(str)       # 错误信息

    # 克隆质量 → 迭代步数映射
    STEP_MAP = {1: 2, 2: 4, 3: 8, 4: 15, 5: 25}

    def __init__(
        self,
        text: str,
        output_path: str,
        profile: dict,
        quality: int = 2,
    ):
        super().__init__()
        self.text = text.strip()
        self.output_path = output_path
        self.profile = profile
        self.quality = quality

    # ------------------------------------------------------------------
    # 引擎路由
    # ------------------------------------------------------------------

    def _build_config(self):
        """根据 profile 构建 OfflineTtsConfig。"""
        t = self.profile["type"]

        if t == "matcha":
            model_dir = "bin/models/matcha"
            matcha_cfg = sherpa_onnx.OfflineTtsMatchaModelConfig(
                acoustic_model=get_asset_path(os.path.join(model_dir, "model-steps-3.onnx")),
                vocoder=get_asset_path(os.path.join(model_dir, "vocos-16khz-univ.onnx")),
                lexicon=get_asset_path(os.path.join(model_dir, "lexicon.txt")),
                tokens=get_asset_path(os.path.join(model_dir, "tokens.txt")),
                data_dir=get_asset_path(os.path.join(model_dir, "espeak-ng-data")),
            )
            model_cfg = sherpa_onnx.OfflineTtsModelConfig(matcha=matcha_cfg, num_threads=2)
            return sherpa_onnx.OfflineTtsConfig(model=model_cfg)

        elif t == "zipvoice":
            model_dir = "bin/models/zipvoice"
            zipvoice_cfg = sherpa_onnx.OfflineTtsZipvoiceModelConfig(
                tokens=get_asset_path(os.path.join(model_dir, "tokens.txt")),
                encoder=get_asset_path(os.path.join(model_dir, "encoder.int8.onnx")),
                decoder=get_asset_path(os.path.join(model_dir, "decoder.int8.onnx")),
                vocoder=get_asset_path(os.path.join(model_dir, "vocos_24khz.onnx")),
                data_dir=get_asset_path(os.path.join(model_dir, "espeak-ng-data")),
                lexicon=get_asset_path(os.path.join(model_dir, "lexicon.txt")),
            )
            model_cfg = sherpa_onnx.OfflineTtsModelConfig(zipvoice=zipvoice_cfg, num_threads=2)
            return sherpa_onnx.OfflineTtsConfig(model=model_cfg)

        elif t == "vits":
            model_dir = self.profile["model_dir"]
            model_file = self.profile.get("model_file", "model.onnx")
            vits_cfg = sherpa_onnx.OfflineTtsVitsModelConfig(
                model=get_asset_path(os.path.join(model_dir, model_file)),
                lexicon=get_asset_path(os.path.join(model_dir, "lexicon.txt")),
                tokens=get_asset_path(os.path.join(model_dir, "tokens.txt")),
                dict_dir=get_asset_path(os.path.join(model_dir, "dict")),
            )
            model_cfg = sherpa_onnx.OfflineTtsModelConfig(vits=vits_cfg, num_threads=2)
            return sherpa_onnx.OfflineTtsConfig(model=model_cfg)

        else:
            raise ValueError(f"Unknown profile type: {t}")

    # ------------------------------------------------------------------
    # 长文切片
    # ------------------------------------------------------------------

    @staticmethod
    def _split_text(text: str) -> list[str]:
        """将长文本按中文标点切分为短句列表，保留标点。"""
        # 匹配：句号 问号 叹号 分号（全角 + 英文）
        pattern = r"([。！？；!?;])"
        parts = re.split(pattern, text)
        sentences: list[str] = []
        buf = ""
        for part in parts:
            if not part:
                continue
            if re.fullmatch(pattern, part):
                buf += part
                if buf.strip():
                    sentences.append(buf)
                buf = ""
            else:
                buf += part
        if buf.strip():
            sentences.append(buf)
        return sentences

    # ------------------------------------------------------------------
    # 音频读取 / 写入
    # ------------------------------------------------------------------

    @staticmethod
    def _read_wav_samples(wav_path: str) -> tuple[np.ndarray, int]:
        """读取 WAV 文件，返回 (float32样本, 采样率)。"""
        with wave.open(wav_path, "rb") as wf:
            n_frames = wf.getnframes()
            sr = wf.getframerate()
            raw = wf.readframes(n_frames)
        samples = np.frombuffer(raw, dtype=np.int16).astype(np.float32) / 32768.0
        return samples, sr

    @staticmethod
    def _write_wav(output_path: str, samples: np.ndarray, sample_rate: int):
        """将 float32 音频数组写入 WAV 文件（int16）。"""
        # 防削波
        peak = float(np.max(np.abs(samples)))
        if peak > 1.0:
            samples = samples / peak * 0.95
        int16 = (samples * 32767).astype(np.int16)

        os.makedirs(os.path.dirname(output_path), exist_ok=True)
        with wave.open(output_path, "wb") as wf:
            wf.setnchannels(1)
            wf.setsampwidth(2)
            wf.setframerate(sample_rate)
            wf.writeframes(int16.tobytes())

    # ------------------------------------------------------------------
    # 主流程
    # ------------------------------------------------------------------

    def run(self):
        try:
            # 1. 构建引擎
            tts_config = self._build_config()
            tts = sherpa_onnx.OfflineTts(tts_config)

            # 2. 切片
            sentences = self._split_text(self.text)
            total = len(sentences)
            if total == 0:
                self.error.emit("文本切片后为空，请检查输入内容。")
                return

            # 3. 逐句合成
            all_samples: list[np.ndarray] = []
            sample_rate = 0

            for idx, sentence in enumerate(sentences):
                pct = int((idx / total) * 100)
                self.progress.emit(pct)

                t = self.profile["type"]

                if t == "matcha":
                    audio = tts.generate(sentence, speed=1.0)
                    all_samples.append(audio.samples)
                    if sample_rate == 0:
                        sample_rate = audio.sample_rate

                elif t == "vits":
                    sid = self.profile.get("sid")
                    if sid is not None:
                        audio = tts.generate(sentence, sid=sid, speed=1.0)
                    else:
                        audio = tts.generate(sentence, speed=1.0)
                    all_samples.append(audio.samples)
                    if sample_rate == 0:
                        sample_rate = audio.sample_rate

                elif t == "zipvoice":
                    ref_wav = self.profile["wav"]
                    ref_text = self.profile.get("text", "")
                    prompt_samples, prompt_sr = self._read_wav_samples(ref_wav)
                    num_steps = self.STEP_MAP.get(self.quality, 4)
                    audio = tts.generate(
                        sentence,
                        prompt_text=ref_text,
                        prompt_samples=prompt_samples.tolist(),
                        sample_rate=prompt_sr,
                        num_steps=num_steps,
                        speed=1.0,
                    )
                    all_samples.append(audio.samples)
                    if sample_rate == 0:
                        sample_rate = audio.sample_rate

            self.progress.emit(100)

            # 4. 拼接
            final_audio = np.concatenate(all_samples)

            # 5. 写入
            self._write_wav(self.output_path, final_audio, sample_rate)
            self.finished.emit(self.output_path)

        except Exception as exc:
            self.error.emit(str(exc))


# ---------------------------------------------------------------------------
# 测试代码
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import sys as _sys
    from PySide6.QtCore import QCoreApplication

    app = QCoreApplication(_sys.argv)

    # --- 测试 Matcha 模式 ---
    text = "你好世界。今天天气真不错！我们去公园散步吧；不过要记得带伞。"
    output = os.path.join(os.path.dirname(__file__), "..", "output", "test_matcha.wav")

    worker = TTSWorker(
        text=text,
        output_path=os.path.abspath(output),
        profile={"type": "matcha"},
    )

    def on_progress(p):
        print(f"[Matcha] 进度: {p}%")
    def on_finished(path):
        print(f"[Matcha] 完成 → {path}")
        app.quit()
    def on_error(msg):
        print(f"[Matcha] 错误: {msg}")
        app.quit()

    worker.progress.connect(on_progress)
    worker.finished.connect(on_finished)
    worker.error.connect(on_error)

    print("Matcha 测试开始...")
    worker.start()
    _sys.exit(app.exec())
