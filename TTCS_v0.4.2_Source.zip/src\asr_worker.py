"""
TTCS V0.2.1 — ASR 听写引擎
基于 sherpa-onnx SenseVoice 离线模型
"""

import os
import wave

import numpy as np
import sherpa_onnx

from utils import get_asset_path

# ---------------------------------------------------------------------------
# 单例 Recognizer（惰性初始化）
# ---------------------------------------------------------------------------

_recognizer: sherpa_onnx.OfflineRecognizer | None = None


def _get_recognizer() -> sherpa_onnx.OfflineRecognizer:
    """返回全局单例 OfflineRecognizer，首次调用时初始化。"""
    global _recognizer
    if _recognizer is not None:
        return _recognizer

    model_path = get_asset_path("bin/models/asr/model.int8.onnx")
    tokens_path = get_asset_path("bin/models/asr/tokens.txt")

    if not os.path.isfile(model_path):
        raise FileNotFoundError(f"ASR 模型未找到: {model_path}")
    if not os.path.isfile(tokens_path):
        raise FileNotFoundError(f"ASR 词表未找到: {tokens_path}")

    _recognizer = sherpa_onnx.OfflineRecognizer.from_sense_voice(
        model=model_path,
        tokens=tokens_path,
        language="zh",
        use_itn=True,
    )
    return _recognizer


# ---------------------------------------------------------------------------
# 公开 API
# ---------------------------------------------------------------------------

def recognize_audio(wav_path: str) -> str:
    """
    对指定 WAV 文件执行离线语音识别。

    要求：16kHz 单声道 16-bit PCM WAV。

    Returns
    -------
    str
        识别出的文本（已启用 ITN 数字转换）。
    """
    recognizer = _get_recognizer()

    with wave.open(wav_path, "rb") as wf:
        sample_rate = wf.getframerate()
        assert wf.getnchannels() == 1, "仅支持单声道 WAV"
        assert wf.getsampwidth() == 2, "仅支持 16-bit PCM"

        num_frames = wf.getnframes()
        raw = wf.readframes(num_frames)
        samples = np.frombuffer(raw, dtype=np.int16).astype(np.float32) / 32768.0

    stream = recognizer.create_stream()
    stream.accept_waveform(sample_rate, samples)
    recognizer.decode_stream(stream)

    return stream.result.text


# ---------------------------------------------------------------------------
# 自检
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import sys, time

    # 追加当前目录到 sys.path（开发模式直接运行）
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

    test_wav = get_asset_path("bin/models/zipvoice/test_wavs/leijun-1.wav")
    if not os.path.isfile(test_wav):
        print(f"[错误] 测试音频不存在: {test_wav}")
        sys.exit(1)

    print(f"测试音频: {test_wav}")
    print("正在识别……")
    t0 = time.perf_counter()
    text = recognize_audio(test_wav)
    elapsed = time.perf_counter() - t0
    print(f"耗时: {elapsed:.2f}s")
    print(f"识别结果: {text}")
