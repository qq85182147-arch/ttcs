@echo off
cd /d "D:\ai\TTCS\TTCS_v0.4.2"
"D:\ai\TTCS\TTCS_v0.4.2\venv\Scripts\python.exe" src\app_main.py
pause