"""
TTCS 底层基建：路径解析、角色档案管理
兼容 Nuitka Standalone 与 Python 开发模式
"""

import json
import os
import sys

# ---------------------------------------------------------------------------
# 路径解析
# ---------------------------------------------------------------------------

def _get_root_dir() -> str:
    """
    返回项目根目录的绝对路径。

    开发模式：通过 __file__ 定位 src/utils.py，向上一级得到根目录。
    Nuitka Standalone 模式：__compiled__ 为 True，则以 exe 所在目录为根。
    """
    if getattr(sys, "frozen", False):
        if hasattr(sys, "_MEIPASS"):
            return sys._MEIPASS
        return os.path.dirname(sys.executable)

    # Nuitka 的 __compiled__ 标记（部分版本）
    if hasattr(__builtins__, "__compiled__") or "__compiled__" in dir(__builtins__):
        return os.path.dirname(sys.argv[0])

    # 开发模式：src/utils.py → 根目录
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def get_asset_path(relative_path: str) -> str:
    """
    根据相对路径返回绝对路径。

    兼容开发环境（以 D:\\ai\\TTCS 为根）和 Nuitka --standalone 目录。
    """
    return os.path.normpath(os.path.join(_get_root_dir(), relative_path))


def get_profiles_dir() -> str:
    """返回 profiles/ 目录的绝对路径。"""
    return get_asset_path("profiles")


def get_profiles_json_path() -> str:
    """返回 profiles/profiles.json 的绝对路径。"""
    return get_asset_path("profiles/profiles.json")

# ---------------------------------------------------------------------------
# 角色档案管理
# ---------------------------------------------------------------------------

def load_profiles() -> dict:
    """
    读取 profiles/profiles.json。

    Returns
    -------
    dict
        形如 {"雷军克隆": {"wav": "ref_1.wav", "text": "Are you ok?"}}
        若文件不存在或损坏，返回空字典。
    """
    json_path = get_profiles_json_path()
    if not os.path.isfile(json_path):
        return {}
    try:
        with open(json_path, "r", encoding="utf-8") as f:
            data = json.load(f)
        if isinstance(data, dict):
            return data
        return {}
    except (json.JSONDecodeError, OSError):
        return {}


def save_profile(name: str, wav_filename: str, text: str) -> None:
    """
    新增一个克隆角色并持久化到 profiles.json。

    Parameters
    ----------
    name : str
        角色名称，如 "雷军克隆"。
    wav_filename : str
        参考音频文件名（相对于 profiles/ 目录或在 profiles/ 下的文件名）。
    text : str
        对应的参考文本。
    """
    profiles = load_profiles()
    profiles[name] = {
        "wav": wav_filename,
        "text": text,
    }

    profiles_dir = get_profiles_dir()
    os.makedirs(profiles_dir, exist_ok=True)

    json_path = get_profiles_json_path()
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(profiles, f, ensure_ascii=False, indent=2)


def delete_profile(name: str) -> None:
    """
    从 profiles.json 中删除指定角色并物理删除其参考音频。

    Parameters
    ----------
    name : str
        角色名称。
    """
    profiles = load_profiles()
    if name not in profiles:
        return

    # 物理删除参考音频
    wav_filename = profiles[name].get("wav", "")
    if wav_filename:
        wav_path = get_asset_path(f"profiles/{wav_filename}")
        if os.path.isfile(wav_path):
            os.remove(wav_path)

    # 从 JSON 中移除
    del profiles[name]

    json_path = get_profiles_json_path()
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(profiles, f, ensure_ascii=False, indent=2)
