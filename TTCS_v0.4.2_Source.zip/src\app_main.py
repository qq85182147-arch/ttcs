"""
TTCS 程序入口
"""

import sys

from PySide6.QtWidgets import QApplication

from tts_ui import TtsUI


def main():
    app = QApplication(sys.argv)
    app.setApplicationName("TTCS")

    # 全局样式（现代简洁）
    app.setStyleSheet("""
        QWidget {
            font-family: "Microsoft YaHei", "Segoe UI", sans-serif;
            font-size: 14px;
        }
        #leftPanel, #rightPanel {
            background: #f5f6fa;
            border-radius: 8px;
        }
        #panelTitle {
            font-size: 16px;
            font-weight: bold;
            color: #2d3436;
            padding: 4px 0 8px 0;
        }
        #roleList {
            background: #ffffff;
            border: 1px solid #dfe6e9;
            border-radius: 6px;
            padding: 4px;
            font-size: 14px;
        }
        #roleList::item {
            padding: 8px 12px;
        }
        #roleList::item:selected {
            background: #0984e3;
            color: white;
            border-radius: 4px;
        }
        #addBtn {
            background: #00b894;
            color: white;
            border: none;
            border-radius: 6px;
            padding: 10px;
            font-size: 15px;
            font-weight: bold;
        }
        #addBtn:hover {
            background: #00a381;
        }
        #textEdit {
            background: #ffffff;
            border: 1px solid #dfe6e9;
            border-radius: 6px;
            padding: 10px;
            font-size: 15px;
        }
        #progressBar {
            border: 1px solid #dfe6e9;
            border-radius: 6px;
            text-align: center;
            font-size: 13px;
            min-height: 22px;
        }
        #progressBar::chunk {
            background: #0984e3;
            border-radius: 5px;
        }
        #synthBtn {
            background: #0984e3;
            color: white;
            border: none;
            border-radius: 8px;
            padding: 12px;
            font-size: 18px;
            font-weight: bold;
        }
        #synthBtn:hover {
            background: #0773c5;
        }
        #synthBtn:disabled {
            background: #b2bec3;
            color: #636e72;
        }
    """)

    window = TtsUI()
    window.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
